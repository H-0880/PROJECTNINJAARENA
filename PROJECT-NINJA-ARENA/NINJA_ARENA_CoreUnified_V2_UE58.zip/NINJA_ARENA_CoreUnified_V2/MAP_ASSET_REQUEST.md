# Recursos que necesito que descargues y me suministres

Para producir el Santuario del Dragón Dorado con assets reales, envíame preferiblemente los archivos/proyectos descargados de Fab sin renombrarlos.

## Prioridad P0
1. Templo o shrine modular japonés.
2. Sakura/cherry blossom.
3. Cliffs/rocks Megascans.
4. Puente rojo japonés o pack con puente.

## Prioridad P1
5. Torii / stone lantern / shrine props.
6. Waterfall/water VFX.
7. Niagara petals / magic / ambient VFX.
8. Ciudad/skyline o arquitectura modular para fondo.

## Qué enviarme
- ZIP original descargado, si Fab lo entrega como archivo.
- O carpeta exportada/pack del proyecto Unreal.
- Para modelos: FBX/GLB + texturas.
- Para packs UE: Content folder o proyecto completo del pack.

No hace falta que los importes primero a NINJA_ARENA. Es preferible revisar el pack original antes de integrarlo.
