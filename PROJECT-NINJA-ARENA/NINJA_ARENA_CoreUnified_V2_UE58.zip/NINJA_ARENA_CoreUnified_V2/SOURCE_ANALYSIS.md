# NINJA_ARENA Source — Combat Fusion V1

## Lo que ya existía en el Source suministrado

El proyecto ya contiene una base de combate propia considerable:

- Light/Heavy melee.
- Input buffer de aproximadamente 160 ms.
- Combo terrestre de 3 pasos.
- Guard y perfect guard.
- Counter especial de Kuroboshi después de perfect guard.
- Launcher pesado y air-combo.
- Air pursuit / aerial systems.
- Dash terrestre y aéreo.
- Wall run / wall jump.
- Lock-on.
- Hit-stop / combat feedback.
- Ultimates.
- Element system.
- Team Battle y Local Versus.
- Hazards y training HUD.
- Perfiles reales de luchadores: Junco, Ascua, Kuroboshi, Raizen, AkiraVioleta, Byakuro, TripoA y TripoB.

Por esto NO conviene reemplazar el combate por FlowSlayer/NightSky/OpenSoulslike.

## Cambios añadidos en esta versión

### `UPNAAdvancedCombatComponent`
Capa aditiva para:
- Weapon/socket trajectory sweep.
- Deduplicación de impacto durante una ventana activa.
- I-Frames.
- Hyper Armor.
- Parry Window.
- Eventos Blueprint para trace hit y parry.

### `UANS_PNAWeaponTrace`
AnimNotifyState que abre/cierra el trace por sockets.

### `UANS_PNAIFrames`
Ventana de invulnerabilidad gobernada por animación.

### `UANS_PNAHyperArmor`
Permite recibir daño sin entrar en hit-stun/launch durante la ventana.

### `UANS_PNAParryWindow`
Parry generalizable. Al acertar, cancela el PendingStrike/buffer del atacante y aplica una breve penalización de stun.

## Integración con `ANINJA_ARENACharacter`

Se añadió `AdvancedCombat` como subcomponente y se conectó al flujo existente de `ReceiveMeleeHit`.

Prioridad defensiva:
1. I-Frame -> ignora el golpe.
2. Parry -> cancela el golpe y penaliza al atacante.
3. Guard/Perfect Guard existente.
4. Hyper Armor -> recibe daño pero no hit-stun/launch.
5. Resolución normal.

El sistema existente de vida, energía, daño, feedback, lock-on, movement y estilos permanece intacto.

## Qué NO se copió

No se copió código fuente de FlowSlayer ni CombatGameplay porque sus ZIP no muestran una licencia raíz explícita. Se estudiaron patrones y se implementó una versión propia PNA.

NightSkyEngine y Open Soulslike Framework sí incluyen licencia MIT en los ZIP suministrados, pero tampoco fue necesario copiar sus subsistemas completos.

## Pendiente dentro de Unreal 5.8

La compilación real con UnrealBuildTool/UHT y PIE no puede ejecutarse en este entorno. Antes de reemplazar tu Source real:

1. backup/commit;
2. copiar esta Source en una rama de prueba;
3. Generate Project Files;
4. Build `NINJA_ARENAEditor`;
5. abrir Editor;
6. colocar los AnimNotifyState en montages de prueba;
7. validar PIE.

## Recomendación de primer uso

- Dash/evasive montage: `PNA I-Frames` sólo durante los frames de evasión real.
- Heavy/Bront-like attack: `PNA Hyper Armor` durante startup tardío + active.
- Counter/parry technique: `PNA Parry Window` de 80–140 ms según personaje.
- Ghostblade/weapon attacks: `PNA Weapon Trace Window` con sockets base/punta de espada.
